package View;

import javax.swing.JPanel;
import com.k33ptoo.components.KButton;
import com.k33ptoo.components.KGradientPanel;

import Controller.CourseController;
import Controller.EntrollmentController;
import Controller.LectureController;
import Controller.StudentController;
import Model.CourseModel;
import Model.EntrollmentModel;
import Model.LectureModel;
import Model.StudentModel;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuPanel extends JPanel {

    public MenuPanel() {
        setBackground(Color.WHITE);
        setLayout(null);

        // Create a gradient panel for the menu
        KGradientPanel gradientPanel = new KGradientPanel();
        gradientPanel.kBorderRadius = 50;
        gradientPanel.setkStartColor(new Color(0, 0, 111));
        gradientPanel.kEndColor = new Color(0, 0, 0);
        gradientPanel.setkEndColor(new Color(0, 0, 0));
        gradientPanel.setBackground(new Color(255, 255, 255));
        gradientPanel.setBounds(0, 0, 199, 560);
        add(gradientPanel);
        gradientPanel.setLayout(null);

        // Add a profile icon
        JLabel lblProfile = new JLabel();
        lblProfile.setIcon(new ImageIcon("E:\\icons\\Circled User Male Skin Type 4.png"));
        lblProfile.setBounds(68, 40, 53, 63);
        gradientPanel.add(lblProfile);

        // Add "Hi" label
        JLabel lblHi = new JLabel("Welcome");
        lblHi.setForeground(new Color(255, 255, 255));
        lblHi.setFont(new Font("Segoe UI", Font.BOLD, 25));
        lblHi.setBounds(41, 132, 117, 32);
        gradientPanel.add(lblHi);
        
        KButton btnStudents = new KButton();
        btnStudents.kHoverForeGround = new Color(0, 0, 160);
        btnStudents.setkHoverForeGround(new Color(0, 0, 160));
        btnStudents.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		StudentModel studentModel=new StudentModel();
        		StudentForm studentForm=new StudentForm();
        		studentForm.setVisible(true);
        		new StudentController(studentForm, studentModel);
        	}
        });
        btnStudents.setBorder(null);
        btnStudents.setText("Students");
        btnStudents.kStartColor = new Color(255, 85, 255);
        btnStudents.setkStartColor(new Color(255, 85, 255));
        btnStudents.kEndColor = new Color(0, 0, 225);
        btnStudents.setkEndColor(new Color(0, 0, 225));
        btnStudents.kBorderRadius = 40;
        btnStudents.setkBorderRadius(40);
        btnStudents.kBackGroundColor = Color.RED;
        btnStudents.setkBackGroundColor(Color.RED);
        btnStudents.setFont(new Font("Tahoma", Font.BOLD, 17));
        btnStudents.setBounds(10, 247, 185, 45);
        gradientPanel.add(btnStudents);
        
        KButton btnCourse = new KButton();
        btnCourse.kHoverForeGround = new Color(0, 0, 160);
        btnCourse.setkHoverForeGround(new Color(0, 0, 160));
        btnCourse.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		CourseModel courseModel=new CourseModel();
        		CourseView courseView=new CourseView();
        	    courseView.setVisible(true);
        	    new CourseController(courseModel, courseView);
        	}
        });
        btnCourse.setText("Course");
        btnCourse.kStartColor = new Color(255, 85, 255);
        btnCourse.setkStartColor(new Color(255, 85, 255));
        btnCourse.kEndColor = new Color(0, 0, 225);
        btnCourse.setkEndColor(new Color(0, 0, 225));
        btnCourse.kBorderRadius = 40;
        btnCourse.setkBorderRadius(40);
        btnCourse.kBackGroundColor = Color.RED;
        btnCourse.setkBackGroundColor(Color.RED);
        btnCourse.setFont(new Font("Tahoma", Font.BOLD, 17));
        btnCourse.setBorder(null);
        btnCourse.setBounds(10, 312, 185, 45);
        gradientPanel.add(btnCourse);
        
        KButton btnLecture = new KButton();
        btnLecture.kHoverForeGround = new Color(0, 0, 160);
        btnLecture.setkHoverForeGround(new Color(0, 0, 160));
        btnLecture.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		LectureModel lectureModel=new LectureModel();
        		lectureView lectureView=new lectureView();
        		lectureView.setVisible(true);
        		new LectureController(lectureModel, lectureView);
        	}
        });
        btnLecture.setText("Lecture");
        btnLecture.kStartColor = new Color(255, 85, 255);
        btnLecture.setkStartColor(new Color(255, 85, 255));
        btnLecture.kEndColor = new Color(0, 0, 225);
        btnLecture.setkEndColor(new Color(0, 0, 225));
        btnLecture.kBorderRadius = 40;
        btnLecture.setkBorderRadius(40);
        btnLecture.kBackGroundColor = Color.RED;
        btnLecture.setkBackGroundColor(Color.RED);
        btnLecture.setFont(new Font("Tahoma", Font.BOLD, 17));
        btnLecture.setBorder(null);
        btnLecture.setBounds(10, 383, 185, 45);
        gradientPanel.add(btnLecture);
        
        KButton btnEntrollment = new KButton();
        btnEntrollment.kHoverForeGround = new Color(0, 0, 160);
        btnEntrollment.setkHoverForeGround(new Color(0, 0, 160));
        btnEntrollment.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		EntrollmentModel entrollmentModel=new EntrollmentModel();
        		EntrollmetView entrollmetView=new EntrollmetView();
        		entrollmetView.setVisible(true);
        		new EntrollmentController(entrollmentModel, entrollmetView);
        	}
        });
        btnEntrollment.setText("Entrollment");
        btnEntrollment.kStartColor = new Color(255, 85, 255);
        btnEntrollment.setkStartColor(new Color(255, 85, 255));
        btnEntrollment.kEndColor = new Color(0, 0, 225);
        btnEntrollment.setkEndColor(new Color(0, 0, 225));
        btnEntrollment.kBorderRadius = 40;
        btnEntrollment.setkBorderRadius(40);
        btnEntrollment.kBackGroundColor = Color.RED;
        btnEntrollment.setkBackGroundColor(Color.RED);
        btnEntrollment.setFont(new Font("Tahoma", Font.BOLD, 17));
        btnEntrollment.setBorder(null);
        btnEntrollment.setBounds(10, 450, 185, 45);
        gradientPanel.add(btnEntrollment);
    }

    // Method to create buttons
    private KButton createMenuButton(String text, int yPosition) {
		return null;
    }
}
