package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.k33ptoo.components.KGradientPanel;

import Controller.RegisterController;
import Model.RegisterModel;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.k33ptoo.components.KButton;
import javax.swing.border.MatteBorder;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Toolkit;

public class LoginForm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtusername;
	private JTextField txtpassword;
	private KButton btnLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm frame = new LoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginForm() {
		setTitle("Education Institute Management System");
		setIconImage(Toolkit.getDefaultToolkit().getImage("E:\\icons\\fbbntn.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 951, 622);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		KGradientPanel gradientPanel = new KGradientPanel();
		gradientPanel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		gradientPanel.kEndColor = new Color(0, 153, 204);
		gradientPanel.setkEndColor(new Color(0, 153, 204));
		gradientPanel.setBounds(0, 0, 981, 598);
		contentPane.add(gradientPanel);
		gradientPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("E:\\icons\\fbbntn.png"));
		lblNewLabel.setBounds(99, 256, 307, 332);
		gradientPanel.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(535, 0, 402, 588);
		gradientPanel.add(panel);
		panel.setLayout(null);
		
		JLabel lblusername = new JLabel("Username");
		lblusername.setBounds(22, 120, 149, 38);
		lblusername.setForeground(new Color(90, 90, 90));
		lblusername.setFont(new Font("Segoe UI", Font.BOLD, 19));
		panel.add(lblusername);
		
		JLabel lblNewLabel_1_1 = new JLabel("Sign In");
		lblNewLabel_1_1.setBounds(28, 38, 98, 38);
		lblNewLabel_1_1.setForeground(new Color(90, 90, 90));
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.BOLD, 24));
		panel.add(lblNewLabel_1_1);
		
		JLabel lblpassword = new JLabel("Password");
		lblpassword.setForeground(new Color(90, 90, 90));
		lblpassword.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblpassword.setBounds(22, 245, 149, 38);
		panel.add(lblpassword);
		
		txtusername = new JTextField();
		txtusername.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtusername.setBounds(62, 185, 283, 31);
		panel.add(txtusername);
		txtusername.setColumns(10);
		
		txtpassword = new JTextField();
		txtpassword.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 128)));
		txtpassword.setColumns(10);
		txtpassword.setBounds(62, 300, 283, 31);
		panel.add(txtpassword);
		
		JLabel lblNewLabel_2 = new JLabel("Click here to Register");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JFrame loginForm = (JFrame) SwingUtilities.getWindowAncestor(lblNewLabel_2);
				if (loginForm != null) {
					loginForm.dispose(); 
					} 
				// Open the register form
				RegisterModel registerModel = new RegisterModel();
				RegisterForm registerForm = new RegisterForm();
				registerForm.setVisible(true); 
				new RegisterController(registerModel, registerForm);
			}
		});
		lblNewLabel_2.setForeground(new Color(183, 0, 183));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_2.setBounds(110, 438, 178, 27);
		panel.add(lblNewLabel_2);
		
		 btnLogin = new KButton();
		 btnLogin.kHoverForeGround = new Color(0, 0, 160);
		 btnLogin.setkHoverForeGround(new Color(0, 0, 160));
		btnLogin.setText("Sign In");
		btnLogin.kStartColor = new Color(255, 85, 255);
		btnLogin.setkStartColor(new Color(255, 85, 255));
		btnLogin.kIndicatorColor = new Color(0, 0, 111);
		btnLogin.setkIndicatorColor(new Color(0, 0, 111));
		btnLogin.kForeGround = new Color(0, 0, 111);
		btnLogin.setkForeGround(new Color(0, 0, 111));
		btnLogin.kEndColor = new Color(0, 0, 225);
		btnLogin.setkEndColor(new Color(0, 0, 225));
		btnLogin.kBorderRadius = 40;
		btnLogin.setkBorderRadius(40);
		btnLogin.kBackGroundColor = Color.RED;
		btnLogin.setkBackGroundColor(Color.RED);
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnLogin.setBorder(null);
		btnLogin.setBounds(103, 375, 185, 45);
		panel.add(btnLogin);
		
		JLabel lblNewLabel_1_2 = new JLabel("Welcome ");
		lblNewLabel_1_2.setForeground(new Color(0, 0, 160));
		lblNewLabel_1_2.setFont(new Font("Segoe UI", Font.BOLD, 28));
		lblNewLabel_1_2.setBounds(160, 81, 165, 45);
		gradientPanel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Education Institute Management ");
		lblNewLabel_1_2_1.setForeground(new Color(0, 0, 160));
		lblNewLabel_1_2_1.setFont(new Font("Segoe UI", Font.BOLD, 28));
		lblNewLabel_1_2_1.setBounds(29, 149, 496, 45);
		gradientPanel.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_2_2 = new JLabel("System");
		lblNewLabel_1_2_2.setForeground(new Color(0, 0, 160));
		lblNewLabel_1_2_2.setFont(new Font("Segoe UI", Font.BOLD, 28));
		lblNewLabel_1_2_2.setBounds(175, 204, 165, 45);
		gradientPanel.add(lblNewLabel_1_2_2);
	}
	
	
    public String getUsername() {
    	return txtusername.getText();
    }
    public String getPassword() {
    	return txtpassword.getText();
    }
	public void addAddButtonListener(ActionListener listener) {
        btnLogin.addActionListener(listener);
    }
}
