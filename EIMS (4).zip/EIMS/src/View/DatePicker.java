package View;
import javax.swing.*;
import java.awt.*;
import java.util.Calendar;

public class DatePicker extends JPanel {
    private JComboBox<Integer> dayComboBox;
    private JComboBox<Integer> monthComboBox;
    private JComboBox<Integer> yearComboBox;

    public DatePicker() {
        setLayout(new FlowLayout());

        // Initialize day combo box
        dayComboBox = new JComboBox<>();
        for (int i = 1; i <= 31; i++) {
            dayComboBox.addItem(i);
        }

        // Initialize month combo box
        monthComboBox = new JComboBox<>();
        for (int i = 1; i <= 12; i++) {
            monthComboBox.addItem(i);
        }

        // Initialize year combo box
        yearComboBox = new JComboBox<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = currentYear; i >= currentYear - 100; i--) {
            yearComboBox.addItem(i);
        }

        // Add combo boxes to the panel
        add(dayComboBox);
        add(monthComboBox);
        add(yearComboBox);
    }

    public String getSelectedDate() {
        int day = (int) dayComboBox.getSelectedItem();
        int month = (int) monthComboBox.getSelectedItem();
        int year = (int) yearComboBox.getSelectedItem();
        return String.format("%d-%02d-%02d", year, month, day);
    }
}

