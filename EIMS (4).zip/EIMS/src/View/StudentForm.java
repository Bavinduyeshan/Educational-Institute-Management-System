package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import com.k33ptoo.components.KGradientPanel;

import Config.DatabaseConnection;
import Controller.ReportController;
import Model.StudentModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

import java.awt.BorderLayout;
import java.awt.Color;

import java.util.List;
import com.k33ptoo.components.KButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.collections.map.StaticBucketMap;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.LineBorder;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class StudentForm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtfname;
	private JTextField txtlname;
	private JTextField txtaddress;
	private JTextField txtemail;
	private KButton btnADD;
	private KButton btnUpdate;
	private KButton btndel;
	private KButton btndashboard;
	private JComboBox<String> cmbgender;
	private JComboBox<Integer>cmbStudentId;
	private JComboBox<Integer>cmbstdid;
	private KButton generateReportButton;
	private JTable table;
	private DefaultTableModel tableModel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentForm frame = new StudentForm();
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentForm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("E:\\icons\\fbbntn.png"));
		setTitle("Education Institute Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1754, 882);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 250, 251));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		

		setContentPane(contentPane);
		contentPane.setLayout(null);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		//JXDatePicker datePicker = new JXDatePicker(); datePicker.setDate(Calendar.getInstance().getTime()); datePicker.setFormats(new SimpleDateFormat("yyyy-MM-dd")); // Add the date picker to the frame frame.add(datePicker);
		
		
		KGradientPanel gradientPanel = new KGradientPanel();
		gradientPanel.setkStartColor(new Color(0, 0, 111));
		gradientPanel.kEndColor = new Color(0, 0, 0);
		gradientPanel.setkEndColor(new Color(0, 0, 0));
		gradientPanel.setkBorderRadius(50);
		gradientPanel.kBorderRadius = 50;
		gradientPanel.setForeground(new Color(255, 255, 255));
		gradientPanel.setBackground(new Color(238, 250, 251));
		gradientPanel.setBounds(10, 155, 232, 627);
		contentPane.add(gradientPanel);
		gradientPanel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Students");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1.setBounds(60, 10, 126, 28);
		gradientPanel.add(lblNewLabel_1);
		
		 btnADD = new KButton();
		 btnADD.kIndicatorColor = new Color(0, 0, 111);
		 btnADD.setkIndicatorColor(new Color(0, 0, 111));
		 btnADD.kForeGround = new Color(0, 0, 111);
		 btnADD.setkForeGround(new Color(0, 0, 111));
		btnADD.setText("ADD");
		btnADD.kStartColor = new Color(255, 85, 255);
		btnADD.setkStartColor(new Color(255, 85, 255));
		btnADD.kEndColor = new Color(0, 0, 225);
		btnADD.setkEndColor(new Color(0, 0, 225));
		btnADD.kBorderRadius = 40;
		btnADD.setkBorderRadius(40);
		btnADD.kBackGroundColor = Color.RED;
		btnADD.setkBackGroundColor(Color.RED);
		btnADD.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnADD.setBorder(null);
		btnADD.setBounds(22, 175, 185, 45);
		gradientPanel.add(btnADD);
		
		 btnUpdate = new KButton();
		btnUpdate.setText("UPDATE");
		btnUpdate.kStartColor = new Color(255, 85, 255);
		btnUpdate.setkStartColor(new Color(255, 85, 255));
		btnUpdate.kEndColor = new Color(0, 0, 225);
		btnUpdate.setkEndColor(new Color(0, 0, 225));
		btnUpdate.kBorderRadius = 40;
		btnUpdate.setkBorderRadius(40);
		btnUpdate.kBackGroundColor = Color.RED;
		btnUpdate.setkBackGroundColor(Color.RED);
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnUpdate.setBorder(null);
		btnUpdate.setBounds(22, 241, 185, 45);
		gradientPanel.add(btnUpdate);
		
		 btndel = new KButton();
		btndel.setText("DELETE");
		btndel.kStartColor = new Color(255, 85, 255);
		btndel.setkStartColor(new Color(255, 85, 255));
		btndel.kEndColor = new Color(0, 0, 225);
		btndel.setkEndColor(new Color(0, 0, 225));
		btndel.kBorderRadius = 40;
		btndel.setkBorderRadius(40);
		btndel.kBackGroundColor = Color.RED;
		btndel.setkBackGroundColor(Color.RED);
		btndel.setFont(new Font("Tahoma", Font.BOLD, 17));
		btndel.setBorder(null);
		btndel.setBounds(22, 311, 185, 45);
		gradientPanel.add(btndel);
		
		 generateReportButton = new KButton();
		generateReportButton.setText("Report");
		generateReportButton.kStartColor = new Color(255, 85, 255);
		generateReportButton.setkStartColor(new Color(255, 85, 255));
		generateReportButton.kEndColor = new Color(0, 0, 225);
		generateReportButton.setkEndColor(new Color(0, 0, 225));
		generateReportButton.kBorderRadius = 40;
		generateReportButton.setkBorderRadius(40);
		generateReportButton.kBackGroundColor = Color.RED;
		generateReportButton.setkBackGroundColor(Color.RED);
		generateReportButton.setFont(new Font("Tahoma", Font.BOLD, 17));
		generateReportButton.setBorder(null);
		generateReportButton.setBounds(22, 376, 185, 45);
		gradientPanel.add(generateReportButton);
		
		KButton btnExit = new KButton();
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int response = JOptionPane.showConfirmDialog(
			                null, // Parent component, null for center screen
			                "Are you sure you want to exit?", // Message
			                "Exit Confirmation", // Title
			                JOptionPane.YES_NO_OPTION // Options: YES and NO
			        );

			        // If the user clicks "Yes", exit the application
			        if (response == JOptionPane.YES_OPTION) {
			            System.exit(0); // Exits the application
			        }			
				
			}
		});
		btnExit.setText("Exit");
		btnExit.kStartColor = new Color(255, 85, 255);
		btnExit.setkStartColor(new Color(255, 85, 255));
		btnExit.kEndColor = new Color(0, 0, 225);
		btnExit.setkEndColor(new Color(0, 0, 225));
		btnExit.kBorderRadius = 40;
		btnExit.setkBorderRadius(40);
		btnExit.kBackGroundColor = Color.RED;
		btnExit.setkBackGroundColor(Color.RED);
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnExit.setBorder(null);
		btnExit.setBounds(22, 517, 185, 45);
		gradientPanel.add(btnExit);
		
		 btndashboard = new KButton();
		btndashboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame Studentform = (JFrame) SwingUtilities.getWindowAncestor(btndashboard);
				if (Studentform  != null) {
					Studentform .dispose(); 
					} 
				DashboardForm dashboardForm=new DashboardForm();
        		dashboardForm.setVisible(true);
			}
		});
		btndashboard.setText("Dashboard");
		btndashboard.kStartColor = new Color(255, 85, 255);
		btndashboard.setkStartColor(new Color(255, 85, 255));
		btndashboard.kEndColor = new Color(0, 0, 225);
		btndashboard.setkEndColor(new Color(0, 0, 225));
		btndashboard.kBorderRadius = 40;
		btndashboard.setkBorderRadius(40);
		btndashboard.kBackGroundColor = Color.RED;
		btndashboard.setkBackGroundColor(Color.RED);
		btndashboard.setFont(new Font("Tahoma", Font.BOLD, 17));
		btndashboard.setBorder(null);
		btndashboard.setBounds(22, 442, 185, 45);
		gradientPanel.add(btndashboard);
		
		KGradientPanel gradientPanel_4 = new KGradientPanel();
		gradientPanel_4.kEndColor = new Color(0, 0, 111);
		gradientPanel_4.setkEndColor(new Color(0, 0, 111));
		gradientPanel_4.setkStartColor(new Color(0, 0, 111));
		gradientPanel_4.setLayout(null);
		gradientPanel_4.kBorderRadius = 40;
		gradientPanel_4.setkBorderRadius(40);
		gradientPanel_4.setBorder(null);
		gradientPanel_4.setBackground(new Color(238, 250, 251));
		gradientPanel_4.setBounds(240, 38, 1206, 67);
		contentPane.add(gradientPanel_4);
		
		JLabel lblStudents = new JLabel("Students");
		lblStudents.setForeground(new Color(255, 255, 255));
		lblStudents.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblStudents.setBounds(619, 10, 166, 32);
		gradientPanel_4.add(lblStudents);
		
		KGradientPanel gradientPanel_4_1 = new KGradientPanel();
		gradientPanel_4_1.setLayout(null);
		gradientPanel_4_1.kFillBackground = false;
		gradientPanel_4_1.setkFillBackground(false);
		gradientPanel_4_1.kBorderRadius = 40;
		gradientPanel_4_1.setkBorderRadius(40);
		gradientPanel_4_1.setBorder(null);
		gradientPanel_4_1.setBackground(Color.WHITE);
		gradientPanel_4_1.setBounds(321, 194, 492, 576);
		contentPane.add(gradientPanel_4_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Student ID");
		lblNewLabel_1_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_1.setBounds(23, 43, 170, 28);
		gradientPanel_4_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("First Name");
		lblNewLabel_1_2.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_2.setBounds(23, 118, 143, 28);
		gradientPanel_4_1.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Last Name");
		lblNewLabel_1_3.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_3.setBounds(23, 181, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_5 = new JLabel("Gender");
		lblNewLabel_1_5.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_5.setBounds(23, 274, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Address");
		lblNewLabel_1_6.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_6.setBounds(23, 364, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Email");
		lblNewLabel_1_7.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_7.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_7.setBounds(23, 435, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_7);
		
		txtfname = new JTextField();
		txtfname.setColumns(10);
		txtfname.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtfname.setBounds(199, 115, 283, 31);
		gradientPanel_4_1.add(txtfname);
		
		txtlname = new JTextField();
		txtlname.setColumns(10);
		txtlname.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtlname.setBounds(199, 178, 283, 31);
		gradientPanel_4_1.add(txtlname);
		
		txtaddress = new JTextField();
		txtaddress.setColumns(10);
		txtaddress.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtaddress.setBounds(199, 364, 283, 31);
		gradientPanel_4_1.add(txtaddress);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtemail.setBounds(199, 435, 283, 31);
		gradientPanel_4_1.add(txtemail);
		
	    cmbStudentId = new JComboBox();
		cmbStudentId.setBackground(new Color(255, 255, 255));
		cmbStudentId.setBounds(203, 48, 279, 28);
		gradientPanel_4_1.add(cmbStudentId);
		
		cmbgender = new JComboBox();
		cmbgender.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		cmbgender.setBackground(Color.WHITE);
		cmbgender.setBounds(199, 279, 279, 28);
		gradientPanel_4_1.add(cmbgender);
		
		
		// Table Setup
        tableModel = new DefaultTableModel(new String[]{"ID", "First Name", "Last Name", "Gender", "Address", "Email"}, 0);
        table = new JTable(tableModel);
        table.setShowVerticalLines(false);
        table.getTableHeader().setBackground(new Color(0,0,114));
        table.getTableHeader().setForeground(new Color(255,255,255));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(823, 264, 701, 200);
        contentPane.add(scrollPane);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(49, 10, 109, 135);
        contentPane.add(lblNewLabel);
        lblNewLabel.setIcon(new ImageIcon("E:\\icons\\gg.png"));
        
        cmbstdid = new JComboBox();
        cmbstdid.setBackground(Color.WHITE);
        cmbstdid.setBounds(982, 202, 279, 28);
        contentPane.add(cmbstdid);

		
		
		
        
		
		cmbStudentId.addActionListener(e -> {
		    Integer selectedId = (Integer) cmbStudentId.getSelectedItem();
		    if (selectedId != null) {
		   
		    	fillStudentDetails(selectedId);
		    }
		});
		loadStudentData();
		
		cmbstdid.addActionListener(e -> {
            if (cmbstdid.getSelectedItem() != null) {
                int selectedId = (Integer) cmbstdid.getSelectedItem();
                displayStudentData(selectedId);
            }
        });
		
		generateReportButton.addActionListener(e -> {
		    try {
		        
		        int studentId = (int) cmbStudentId.getSelectedItem();  

		        
		        if (studentId <= 0) {
		            JOptionPane.showMessageDialog(null, "Please select a valid student ID.");
		            return;
		        }

		        
		        ReportController reportController = new ReportController();
		        reportController.generateStudentReport(studentId);  // Use the method from the controller

		    } catch (Exception ex) {
		        ex.printStackTrace();
		        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		    }
		});


	
		
		
	}
	
	public int getStudentID() {
		return (int) cmbStudentId.getSelectedItem();
	}
	
	public String getFname() {
	 return	txtfname.getText();
	}
	
	public String getLname() {
		return txtlname.getText();
	}
	public String getGender() {
		return (String) cmbgender.getSelectedItem();
	}
	public String getAddress() {
		return txtaddress.getText();
	}
	public String getEmail() {
		return txtemail.getText();
	}
	public void addAddButtonListener(ActionListener listener) {
        btnADD.addActionListener(listener);
    }
	
	public void addUPDATEButtonListener(ActionListener listener) {
        btnUpdate.addActionListener(listener);
    }
	
	public void addDELETEButtonListener(ActionListener listener) {
        btndel.addActionListener(listener);
    }
	
	
	public void addGenerateReportButtonListener(ActionListener listener) {
	    generateReportButton.addActionListener(listener);
	}

	
//	private  void showStudentReport(int studentId) {
//	    try {
//	        // Compile the JRXML file to Jasper (you can compile it once and reuse the .jasper file)
//	        String sourceFile = "src/student_report.jrxml";
//	        String compiledFile = "src/student_report.jasper";
//	        JasperCompileManager.compileReportToFile(sourceFile, compiledFile);
//
//	        // Get student data from the controller
//	        List<StudentModel> students = StudentModel.getStudentById(studentId);  // Fetch the student data
//	        if (students.isEmpty()) {
//	            JOptionPane.showMessageDialog(null, "No student found with ID: " + studentId);
//	            return;
//	        }
//
//	        // Convert the list of students to a JRBeanCollectionDataSource
//	        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(students);
//
//	        // Fill the report with data
//	        JasperPrint jasperPrint = JasperFillManager.fillReport(compiledFile, null, dataSource);
//
//	        // View the report
//	        JasperViewer.viewReport(jasperPrint, false);
//
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//	    }
//	}

	
	
	public void fillStudentIdComboBox() {
	    String sql = "SELECT studentId FROM Students";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbStudentId.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbStudentId.addItem(resultSet.getInt("studentId")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	public void fillStudentIdSearchComboBox() {
	    String sql = "SELECT studentId FROM Students";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbstdid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbstdid.addItem(resultSet.getInt("studentId")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	

	public void loadStudentData() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Students")) {
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0); 
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("studentId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("gender"),
                        rs.getString("Address"),
                        rs.getString("email")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
	
	
	 public StudentModel getStudentById(int studentId) {
	        String sqlString = "SELECT * FROM Students WHERE studentId=?";
	        StudentModel student = null;

	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(sqlString)) {

	            statement.setInt(1, studentId);
	            ResultSet resultSet = statement.executeQuery();

	            if (resultSet.next()) {
	                student = new StudentModel();
	                student.setStudentid(resultSet.getInt("studentId"));
	                student.setFname(resultSet.getString("firstName"));
	                student.setLname(resultSet.getString("lastName"));
	                student.setGender(resultSet.getString("gender"));
	                student.setAddress(resultSet.getString("Address"));
	                student.setEmail(resultSet.getString("email"));
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	        }

	        return student;
	    }
	
	 
	 
	 
	 private void displayStudentData(int studentId) {
	        
	        tableModel.setRowCount(0);

	        try (Connection con = DatabaseConnection.getConnection();
	             PreparedStatement ps = con.prepareStatement("SELECT * FROM students WHERE studentId = ?")) {
	            ps.setInt(1, studentId);
	            ResultSet rs = ps.executeQuery();

	            while (rs.next()) {
	                tableModel.addRow(new Object[] {
	                		rs.getInt("studentId"),
	                        rs.getString("firstName"),
	                        rs.getString("lastName"),
	                        rs.getString("gender"),
	                        rs.getString("Address"),
	                        rs.getString("email")
	                });
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	private void fillStudentDetails(int studentId) {
	    String query = "SELECT firstName, lastName,gender, address, email FROM Students WHERE studentId = ?";
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, studentId);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                txtfname.setText(rs.getString("firstName"));
	                txtlname.setText(rs.getString("lastName"));
	                txtaddress.setText(rs.getString("address"));
	                txtemail.setText(rs.getString("email"));
	                cmbgender.setSelectedItem(rs.getString("gender"));
	                
	            } else {
	                JOptionPane.showMessageDialog(this, "No student found with ID: " + studentId, "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(this, "Error fetching student details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
}
