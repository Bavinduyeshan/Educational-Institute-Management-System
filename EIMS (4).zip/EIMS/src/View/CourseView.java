package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import com.k33ptoo.components.KGradientPanel;

import Config.DatabaseConnection;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.k33ptoo.components.KButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class CourseView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtcoursename;
	private JTextField txtcoursedes;
	private JTextField txtcredits;
	private KButton btnADD;
	private KButton btnUpdate;
	private KButton btndel;
	private KButton  btnDashboard;
	private JComboBox<Integer>cmblecid;
	private JComboBox<Integer>cmbcourseid;
	private JTable table;
	private DefaultTableModel tableModel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CourseView frame = new CourseView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CourseView() {
		setTitle("Education Institute Management System");
		setIconImage(Toolkit.getDefaultToolkit().getImage("E:\\icons\\fbbntn.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1748, 878);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
	    
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBackground(new Color(238, 250, 251));
		contentPane_1.setBounds(0, 0, 1636, 845);
		contentPane.add(contentPane_1);
		
		KGradientPanel gradientPanel = new KGradientPanel();
		gradientPanel.setkStartColor(new Color(0, 0, 111));
		gradientPanel.kEndColor = new Color(0, 0, 0);
		gradientPanel.setkEndColor(new Color(0, 0, 0));
		gradientPanel.kBorderRadius = 50;
		gradientPanel.setLayout(null);
		gradientPanel.setForeground(Color.WHITE);
		gradientPanel.setBackground(new Color(238, 250, 251));
		gradientPanel.setBounds(10, 183, 232, 652);
		contentPane_1.add(gradientPanel);
		
		JLabel lblNewLabel_1 = new JLabel("Courses");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1.setBounds(55, 25, 126, 28);
		gradientPanel.add(lblNewLabel_1);
		
		 btnADD = new KButton();
		 btnADD.kHoverForeGround = new Color(0, 0, 160);
		 btnADD.setkHoverForeGround(new Color(0, 0, 160));
		btnADD.setText("ADD");
		btnADD.kStartColor = new Color(255, 85, 255);
		btnADD.setkStartColor(new Color(255, 85, 255));
		btnADD.kEndColor = new Color(0, 0, 225);
		btnADD.setkEndColor(new Color(0, 0, 225));
		btnADD.kBorderRadius = 40;
		btnADD.setkBorderRadius(40);
		btnADD.kBackGroundColor = Color.RED;
		btnADD.setkBackGroundColor(Color.RED);
		btnADD.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnADD.setBorder(null);
		btnADD.setBounds(22, 188, 185, 45);
		gradientPanel.add(btnADD);
		
		 btnUpdate = new KButton();
		 btnUpdate.kHoverForeGround = new Color(0, 0, 160);
		 btnUpdate.setkHoverForeGround(new Color(0, 0, 160));
		btnUpdate.setText("UPDATE");
		btnUpdate.kStartColor = new Color(255, 85, 255);
		btnUpdate.setkStartColor(new Color(255, 85, 255));
		btnUpdate.kEndColor = new Color(0, 0, 225);
		btnUpdate.setkEndColor(new Color(0, 0, 225));
		btnUpdate.kBorderRadius = 40;
		btnUpdate.setkBorderRadius(40);
		btnUpdate.kBackGroundColor = Color.RED;
		btnUpdate.setkBackGroundColor(Color.RED);
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnUpdate.setBorder(null);
		btnUpdate.setBounds(22, 285, 185, 45);
		gradientPanel.add(btnUpdate);
		
		 btndel = new KButton();
		 btndel.kHoverForeGround = new Color(0, 0, 160);
		 btndel.setkHoverForeGround(new Color(0, 0, 160));
		btndel.setText("DELETE");
		btndel.kStartColor = new Color(255, 85, 255);
		btndel.setkStartColor(new Color(255, 85, 255));
		btndel.kEndColor = new Color(0, 0, 225);
		btndel.setkEndColor(new Color(0, 0, 225));
		btndel.kBorderRadius = 40;
		btndel.setkBorderRadius(40);
		btndel.kBackGroundColor = Color.RED;
		btndel.setkBackGroundColor(Color.RED);
		btndel.setFont(new Font("Tahoma", Font.BOLD, 17));
		btndel.setBorder(null);
		btndel.setBounds(22, 361, 185, 45);
		gradientPanel.add(btndel);
		
		 btnDashboard = new KButton();
		btnDashboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame Courseform = (JFrame) SwingUtilities.getWindowAncestor(btnDashboard);
				if (Courseform  != null) {
					Courseform .dispose(); 
					} 
				DashboardForm dashboardForm=new DashboardForm();
        		dashboardForm.setVisible(true);
			}
		});
		btnDashboard.kHoverForeGround = new Color(0, 0, 160);
		btnDashboard.setkHoverForeGround(new Color(0, 0, 160));
		btnDashboard.setText("Dashboard");
		btnDashboard.kStartColor = new Color(255, 85, 255);
		btnDashboard.setkStartColor(new Color(255, 85, 255));
		btnDashboard.kEndColor = new Color(0, 0, 225);
		btnDashboard.setkEndColor(new Color(0, 0, 225));
		btnDashboard.kBorderRadius = 40;
		btnDashboard.setkBorderRadius(40);
		btnDashboard.kBackGroundColor = new Color(0, 255, 0);
		btnDashboard.setkBackGroundColor(new Color(0, 255, 0));
		btnDashboard.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnDashboard.setBorder(null);
		btnDashboard.setBounds(22, 431, 185, 45);
		gradientPanel.add(btnDashboard);
		
		KButton btnexit = new KButton();
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int response = JOptionPane.showConfirmDialog(
			                null, 
			                "Are you sure you want to exit?", 
			                "Exit Confirmation", // Title
			                JOptionPane.YES_NO_OPTION 
			        );

			        
			        if (response == JOptionPane.YES_OPTION) {
			            System.exit(0); 
			        }			}
		});
		btnexit.kHoverForeGround = new Color(0, 0, 160);
		btnexit.setkHoverForeGround(new Color(0, 0, 160));
		btnexit.setText("Exit");
		btnexit.kStartColor = new Color(255, 85, 255);
		btnexit.setkStartColor(new Color(255, 85, 255));
		btnexit.kEndColor = new Color(0, 0, 225);
		btnexit.setkEndColor(new Color(0, 0, 225));
		btnexit.kBorderRadius = 40;
		btnexit.setkBorderRadius(40);
		btnexit.kBackGroundColor = Color.RED;
		btnexit.setkBackGroundColor(Color.RED);
		btnexit.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnexit.setBorder(null);
		btnexit.setBounds(22, 497, 185, 45);
		gradientPanel.add(btnexit);
		
		KGradientPanel gradientPanel_4 = new KGradientPanel();
		gradientPanel_4.setkStartColor(new Color(0, 0, 111));
		gradientPanel_4.kEndColor = new Color(0, 0, 111);
		gradientPanel_4.setkEndColor(new Color(0, 0, 111));
		gradientPanel_4.setLayout(null);
		gradientPanel_4.kBorderRadius = 40;
		gradientPanel_4.setkBorderRadius(40);
		gradientPanel_4.setBorder(null);
		gradientPanel_4.setBackground(new Color(238, 250, 251));
		gradientPanel_4.setBounds(242, 38, 1148, 67);
		contentPane_1.add(gradientPanel_4);
		
		JLabel lblCourses = new JLabel("Courses");
		lblCourses.setForeground(new Color(255, 255, 255));
		lblCourses.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblCourses.setBounds(519, 10, 166, 32);
		gradientPanel_4.add(lblCourses);
		
		KGradientPanel gradientPanel_4_1 = new KGradientPanel();
		gradientPanel_4_1.setLayout(null);
		gradientPanel_4_1.kFillBackground = false;
		gradientPanel_4_1.setkFillBackground(false);
		gradientPanel_4_1.kBorderRadius = 40;
		gradientPanel_4_1.setkBorderRadius(40);
		gradientPanel_4_1.setBorder(null);
		gradientPanel_4_1.setBackground(Color.WHITE);
		gradientPanel_4_1.setBounds(321, 183, 492, 576);
		contentPane_1.add(gradientPanel_4_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Course ID");
		lblNewLabel_1_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_1.setBounds(23, 43, 170, 28);
		gradientPanel_4_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Course Name");
		lblNewLabel_1_2.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_2.setBounds(23, 118, 166, 28);
		gradientPanel_4_1.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Description");
		lblNewLabel_1_3.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_3.setBounds(23, 181, 147, 28);
		gradientPanel_4_1.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_5 = new JLabel("Lecture Id");
		lblNewLabel_1_5.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_5.setBounds(23, 321, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_5);
		
		txtcoursename = new JTextField();
		txtcoursename.setColumns(10);
		txtcoursename.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtcoursename.setBounds(199, 115, 283, 31);
		gradientPanel_4_1.add(txtcoursename);
		
		txtcoursedes = new JTextField();
		txtcoursedes.setColumns(10);
		txtcoursedes.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtcoursedes.setBounds(199, 178, 283, 31);
		gradientPanel_4_1.add(txtcoursedes);
		
		 cmbcourseid = new JComboBox();
		cmbcourseid.setBackground(Color.WHITE);
		cmbcourseid.setBounds(203, 48, 279, 28);
		gradientPanel_4_1.add(cmbcourseid);
		
		 cmblecid = new JComboBox();
		cmblecid.setBackground(Color.WHITE);
		cmblecid.setBounds(199, 321, 279, 28);
		gradientPanel_4_1.add(cmblecid);
		
		JLabel lblNewLabel_1_5_1 = new JLabel("Credits");
		lblNewLabel_1_5_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_5_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_5_1.setBounds(23, 252, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_5_1);
		
		txtcredits = new JTextField();
		txtcredits.setColumns(10);
		txtcredits.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtcredits.setBounds(199, 252, 283, 31);
		gradientPanel_4_1.add(txtcredits);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(58, 10, 109, 163);
		contentPane_1.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon("E:\\icons\\gg.png"));
		
		
        tableModel = new DefaultTableModel(new String[]{"CourseId", "CourseName", "Description", "Credits", "LectureId"}, 0);
        table = new JTable(tableModel);
        table.setShowVerticalLines(false);
        table.getTableHeader().setBackground(new Color(0,0,114));
        table.getTableHeader().setForeground(new Color(255,255,255));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(898, 248, 701, 200);
        contentPane_1.add(scrollPane);
		
		cmbcourseid.addActionListener(e -> {
		    Integer selectedId = (Integer) cmbcourseid.getSelectedItem();
		    if (selectedId != null) {
		   
		    	fillCourseDetails(selectedId);
		    }
		});
		loadCourseData();
	}
	
	public int getCourseid() {
		return (int) cmbcourseid.getSelectedItem();
		
	}
	public int getlecid() {
		return (int) cmblecid.getSelectedItem();
		
	}
	public String getCoursename() {
		return txtcoursename.getText();
		
	}
	public String getcoursedes() {
		return txtcoursedes.getText();
		
	}
	
	public int getcredits() {
		return txtcredits.NEXT;
		
	}
	
	
	public void addAddButtonListener(ActionListener listener) {
        btnADD.addActionListener(listener);
    }
	
	public void addUPDATEButtonListener(ActionListener listener) {
        btnUpdate.addActionListener(listener);
    }
	
	public void addDELETEButtonListener(ActionListener listener) {
        btndel.addActionListener(listener);
    }
	
	
	public void fillLectureIdComboBox() {
	    String sql = "SELECT lectureID FROM Lectures";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmblecid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmblecid.addItem(resultSet.getInt("lectureID")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	public void fillCourseIdComboBox() {
	    String sql = "SELECT courseID FROM Courses";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbcourseid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbcourseid.addItem(resultSet.getInt("courseID")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	private void fillCourseDetails(int courseID) {
	    String query = "SELECT courseName,courseDescription,credits,lectureID FROM Courses WHERE courseID = ?";
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, courseID);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                txtcoursename.setText(rs.getString("courseName"));
	                
	                txtcoursedes.setText(rs.getString("courseDescription"));
	                txtcredits.setText(rs.getString("credits"));
	                cmblecid.setSelectedItem(rs.getString("lectureID"));
	                
	            } else {
	                JOptionPane.showMessageDialog(this, "No student found with ID: " + courseID, "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(this, "Error fetching student details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	public void loadCourseData() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Courses")) {
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0); 
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("courseID"),
                        rs.getString("courseName"),
                        rs.getString("courseDescription"),
                        rs.getInt("credits"),
                        rs.getInt("lectureID"),
                        
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
}
