package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import com.k33ptoo.components.KGradientPanel;

import Config.DatabaseConnection;
import Controller.ReportController;
import Model.EntrollmentModel;
import Model.StudentModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.k33ptoo.components.KButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class EntrollmetView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private KButton btnADD;
	private KButton btnUpdate;
	private KButton btndel;
	private KButton btnreport;
	private KButton btnDashboard;
	private JComboBox<Integer> cmbEnid;
	private JComboBox<Integer>cmbStid;
	private JComboBox<Integer>cmbcourseid;
	private JComboBox<Integer>cmbSearchCourseid;
	private JTable table;
	private DefaultTableModel tableModel;
	private JTable table2;
	private DefaultTableModel tableModel2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EntrollmetView frame = new EntrollmetView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EntrollmetView() {
		setTitle("Education Institute Management System");
		setIconImage(Toolkit.getDefaultToolkit().getImage("E:\\icons\\fbbntn.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1554, 1155);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBackground(new Color(238, 250, 251));
		contentPane_1.setBounds(0, 0, 1632, 845);
		contentPane.add(contentPane_1);
		
		KGradientPanel gradientPanel = new KGradientPanel();
		gradientPanel.setLayout(null);
		gradientPanel.kStartColor = new Color(0, 0, 111);
		gradientPanel.setkStartColor(new Color(0, 0, 111));
		gradientPanel.kEndColor = Color.BLACK;
		gradientPanel.setkEndColor(Color.BLACK);
		gradientPanel.kBorderRadius = 50;
		gradientPanel.setkBorderRadius(50);
		gradientPanel.setForeground(Color.WHITE);
		gradientPanel.setBackground(new Color(238, 250, 251));
		gradientPanel.setBounds(10, 194, 232, 582);
		contentPane_1.add(gradientPanel);
		
		JLabel lblNewLabel_1 = new JLabel("Entrollment");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1.setBounds(52, 40, 144, 28);
		gradientPanel.add(lblNewLabel_1);
		
		 btnADD = new KButton();
		 btnADD.kHoverForeGround = new Color(0, 0, 160);
		 btnADD.setkHoverForeGround(new Color(0, 0, 160));
		btnADD.setText("ADD");
		btnADD.kStartColor = new Color(255, 85, 255);
		btnADD.setkStartColor(new Color(255, 85, 255));
		btnADD.kEndColor = new Color(0, 0, 225);
		btnADD.setkEndColor(new Color(0, 0, 225));
		btnADD.kBorderRadius = 40;
		btnADD.setkBorderRadius(40);
		btnADD.kBackGroundColor = Color.RED;
		btnADD.setkBackGroundColor(Color.RED);
		btnADD.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnADD.setBorder(null);
		btnADD.setBounds(22, 140, 185, 45);
		gradientPanel.add(btnADD);
		
		 btnUpdate = new KButton();
		 btnUpdate.kHoverForeGround = new Color(0, 0, 160);
		 btnUpdate.setkHoverForeGround(new Color(0, 0, 160));
		btnUpdate.setText("UPDATE");
		btnUpdate.kStartColor = new Color(255, 85, 255);
		btnUpdate.setkStartColor(new Color(255, 85, 255));
		btnUpdate.kEndColor = new Color(0, 0, 225);
		btnUpdate.setkEndColor(new Color(0, 0, 225));
		btnUpdate.kBorderRadius = 40;
		btnUpdate.setkBorderRadius(40);
		btnUpdate.kBackGroundColor = Color.RED;
		btnUpdate.setkBackGroundColor(Color.RED);
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnUpdate.setBorder(null);
		btnUpdate.setBounds(22, 217, 185, 45);
		gradientPanel.add(btnUpdate);
		
		 btndel = new KButton();
		 btndel.kHoverForeGround = new Color(0, 0, 160);
		 btndel.setkHoverForeGround(new Color(0, 0, 160));
		btndel.setText("DELETE");
		btndel.kStartColor = new Color(255, 85, 255);
		btndel.setkStartColor(new Color(255, 85, 255));
		btndel.kEndColor = new Color(0, 0, 225);
		btndel.setkEndColor(new Color(0, 0, 225));
		btndel.kBorderRadius = 40;
		btndel.setkBorderRadius(40);
		btndel.kBackGroundColor = Color.RED;
		btndel.setkBackGroundColor(Color.RED);
		btndel.setFont(new Font("Tahoma", Font.BOLD, 17));
		btndel.setBorder(null);
		btndel.setBounds(22, 293, 185, 45);
		gradientPanel.add(btndel);
		
		 btnreport = new KButton();
		 btnreport.kHoverForeGround = new Color(0, 0, 160);
		 btnreport.setkHoverForeGround(new Color(0, 0, 160));
		btnreport.setText("Report");
		btnreport.kStartColor = new Color(255, 85, 255);
		btnreport.setkStartColor(new Color(255, 85, 255));
		btnreport.kEndColor = new Color(0, 0, 225);
		btnreport.setkEndColor(new Color(0, 0, 225));
		btnreport.kBorderRadius = 40;
		btnreport.setkBorderRadius(40);
		btnreport.kBackGroundColor = Color.RED;
		btnreport.setkBackGroundColor(Color.RED);
		btnreport.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnreport.setBorder(null);
		btnreport.setBounds(22, 369, 185, 45);
		gradientPanel.add(btnreport);
		
		 btnDashboard = new KButton();
		 btnDashboard.setkHoverForeGround(new Color(0, 0, 160));
		 btnDashboard.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		JFrame Entrollmentform = (JFrame) SwingUtilities.getWindowAncestor(btnDashboard);
				if (Entrollmentform != null) {
					Entrollmentform.dispose(); 
					} 
				DashboardForm dashboardForm=new DashboardForm();
        		dashboardForm.setVisible(true);
		 	}
		 });
//		btnDashboard.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
////				DashboardForm dashboardForm=new DashboardForm();
////				dashboardForm.setVisible(true);
//			}
//		});
		btnDashboard.setText("Dashboard");
		btnDashboard.kStartColor = new Color(255, 85, 255);
		btnDashboard.setkStartColor(new Color(255, 85, 255));
		btnDashboard.kEndColor = new Color(0, 0, 225);
		btnDashboard.setkEndColor(new Color(0, 0, 225));
		btnDashboard.kBorderRadius = 40;
		btnDashboard.setkBorderRadius(40);
		btnDashboard.kBackGroundColor = Color.RED;
		btnDashboard.setkBackGroundColor(Color.RED);
		btnDashboard.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnDashboard.setBorder(null);
		btnDashboard.setBounds(22, 443, 185, 45);
		gradientPanel.add(btnDashboard);
		
		KButton btnExit = new KButton();
		btnExit.kHoverForeGround = new Color(0, 0, 160);
		btnExit.setkHoverForeGround(new Color(0, 0, 160));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 int response = JOptionPane.showConfirmDialog(
			                null, 
			                "Are you sure you want to exit?", 
			                "Exit Confirmation", 
			                JOptionPane.YES_NO_OPTION 
			        );

			        
			        if (response == JOptionPane.YES_OPTION) {
			            System.exit(0); 
			        }			
			}
		});
		btnExit.setText("Exit");
		btnExit.kStartColor = new Color(255, 85, 255);
		btnExit.setkStartColor(new Color(255, 85, 255));
		btnExit.kEndColor = new Color(0, 0, 225);
		btnExit.setkEndColor(new Color(0, 0, 225));
		btnExit.kBorderRadius = 40;
		btnExit.setkBorderRadius(40);
		btnExit.kBackGroundColor = Color.RED;
		btnExit.setkBackGroundColor(Color.RED);
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnExit.setBorder(null);
		btnExit.setBounds(22, 509, 185, 45);
		gradientPanel.add(btnExit);
		
		KGradientPanel gradientPanel_4 = new KGradientPanel();
		gradientPanel_4.setLayout(null);
		gradientPanel_4.kStartColor = new Color(0, 0, 111);
		gradientPanel_4.setkStartColor(new Color(0, 0, 111));
		gradientPanel_4.kEndColor = new Color(0, 0, 111);
		gradientPanel_4.setkEndColor(new Color(0, 0, 111));
		gradientPanel_4.kBorderRadius = 40;
		gradientPanel_4.setkBorderRadius(40);
		gradientPanel_4.setBorder(null);
		gradientPanel_4.setBackground(new Color(238, 250, 251));
		gradientPanel_4.setBounds(234, 38, 1116, 67);
		contentPane_1.add(gradientPanel_4);
		
		JLabel lblEntrollment = new JLabel("Entrollment");
		lblEntrollment.setForeground(Color.WHITE);
		lblEntrollment.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblEntrollment.setBounds(535, 10, 166, 32);
		gradientPanel_4.add(lblEntrollment);
		
		KGradientPanel gradientPanel_4_1 = new KGradientPanel();
		gradientPanel_4_1.setLayout(null);
		gradientPanel_4_1.kFillBackground = false;
		gradientPanel_4_1.setkFillBackground(false);
		gradientPanel_4_1.kBorderRadius = 40;
		gradientPanel_4_1.setkBorderRadius(40);
		gradientPanel_4_1.setBorder(null);
		gradientPanel_4_1.setBackground(Color.WHITE);
		gradientPanel_4_1.setBounds(321, 194, 585, 263);
		contentPane_1.add(gradientPanel_4_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Entrollment ID");
		lblNewLabel_1_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_1.setBounds(10, 43, 230, 28);
		gradientPanel_4_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Student ID");
		lblNewLabel_1_2.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_2.setBounds(23, 118, 166, 28);
		gradientPanel_4_1.add(lblNewLabel_1_2);
		
		 cmbEnid = new JComboBox();
		cmbEnid.setBackground(Color.WHITE);
		cmbEnid.setBounds(203, 48, 279, 28);
		gradientPanel_4_1.add(cmbEnid);
		
		JLabel lblNewLabel_1_7_1 = new JLabel("Course ID");
		lblNewLabel_1_7_1.setForeground(new Color(0, 0, 128));
		lblNewLabel_1_7_1.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel_1_7_1.setBounds(23, 185, 126, 28);
		gradientPanel_4_1.add(lblNewLabel_1_7_1);
		
		 cmbcourseid = new JComboBox();
		cmbcourseid.setBackground(Color.WHITE);
		cmbcourseid.setBounds(203, 185, 279, 28);
		gradientPanel_4_1.add(cmbcourseid);
		
		 cmbStid = new JComboBox();
		cmbStid.setBackground(Color.WHITE);
		cmbStid.setBounds(199, 118, 279, 28);
		gradientPanel_4_1.add(cmbStid);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("E:\\icons\\gg.png"));
		lblNewLabel.setBounds(58, 10, 109, 163);
		contentPane_1.add(lblNewLabel);
		
		
		
		 tableModel = new DefaultTableModel(new String[]{"Entrollment Id", "StudentId", "CourseId", "Entrollment date"}, 0);
	        table = new JTable(tableModel);
	        table.setShowVerticalLines(false);
	        table.getTableHeader().setBackground(new Color(0,0,114));
	        table.getTableHeader().setForeground(new Color(255,255,255));
	        JScrollPane scrollPane = new JScrollPane(table);
	        scrollPane.setBounds(933, 217, 578, 200);
	        contentPane_1.add(scrollPane);
	        
	     
	        tableModel2 = new DefaultTableModel(new String[]{"Student ID", "Student Name", "Enrollment Date"}, 0);

	        
	        table2 = new JTable(tableModel2);
	        table2.setShowVerticalLines(false);
	        table2.getTableHeader().setBackground(new Color(0, 0, 114));
	        table2.getTableHeader().setForeground(new Color(255, 255, 255));

	       
	        JScrollPane scrollPane2 = new JScrollPane(table2);
	        scrollPane2.setBounds(537, 635, 578, 200); 
	        contentPane_1.add(scrollPane2);
	        
	         cmbSearchCourseid = new JComboBox();
	        cmbSearchCourseid.setBackground(Color.WHITE);
	        cmbSearchCourseid.setBounds(819, 558, 279, 28);
	        contentPane_1.add(cmbSearchCourseid);
	        
	        JLabel lblNewLabel_1_7_1_1 = new JLabel("Course ID");
	        lblNewLabel_1_7_1_1.setForeground(new Color(0, 0, 128));
	        lblNewLabel_1_7_1_1.setFont(new Font("Tahoma", Font.BOLD, 23));
	        lblNewLabel_1_7_1_1.setBounds(614, 558, 126, 28);
	        contentPane_1.add(lblNewLabel_1_7_1_1);
	        
	        
	        
	        cmbEnid.addActionListener(e -> {
			    Integer selectedId = (Integer) cmbEnid.getSelectedItem();
			    if (selectedId != null) {
			   
			    	fillEntryDetails(selectedId);
			    }
			});
	        
	        loadEntrollmentData();
	        
	        cmbSearchCourseid.addActionListener(e -> {
	            Integer selectedCourseId = (Integer) cmbSearchCourseid.getSelectedItem();
	            if (selectedCourseId != null) {
	                showStudentsForCourse(selectedCourseId);
	            }
	        });
	        
	        
	        btnreport.addActionListener(e -> {
	            try {
	                
	                int courseId = (int) cmbSearchCourseid.getSelectedItem();  // Assuming the combo box holds course IDs as integers

	                
	                if (courseId <= 0) {
	                    JOptionPane.showMessageDialog(null, "Please select a valid course ID.");
	                    return;
	                }

	                
	                ReportController reportController = new ReportController();
	                reportController.generateCourseReport(courseId);  

	            } catch (Exception ex) {
	                ex.printStackTrace();
	                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	            }
	        });


	}
	
	public int getCourseId() {
		return (int) cmbcourseid.getSelectedItem();
		
	}
	public int getstudentId() {
		return (int) cmbStid.getSelectedItem();
		
	}
	public int getEntrolmentId() {
		return (int) cmbEnid.getSelectedItem();
		
	}
	
	
	
	
	public void addAddButtonListener(ActionListener listener) {
        btnADD.addActionListener(listener);
    }
	public void addDashboardButtonListener(ActionListener listener) {
        btnADD.addActionListener(listener);
    }
	
	public void addUPDATEButtonListener(ActionListener listener) {
        btnUpdate.addActionListener(listener);
    }
	
	public void addDELETEButtonListener(ActionListener listener) {
        btndel.addActionListener(listener);
    }
	
	
	
	
	public void fillCourseIdComboBox() {
	    String sql = "SELECT courseID FROM Courses";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbcourseid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbcourseid.addItem(resultSet.getInt("courseID")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	public void fillSearchCourseIdComboBox() {
	    String sql = "SELECT courseID FROM Courses";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbSearchCourseid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbSearchCourseid.addItem(resultSet.getInt("courseID")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	public void fillStudentIdComboBox() {
	    String sql = "SELECT studentId FROM Students";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbStid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbStid.addItem(resultSet.getInt("studentId")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	public void fillEntrollmentIdComboBox() {
		String sql = "SELECT enrollment_id FROM Enrollments";
	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {

	        cmbEnid.removeAllItems(); 
	        while (resultSet.next()) {
	            cmbEnid.addItem(resultSet.getInt("enrollment_id")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	public void loadEntrollmentData() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Enrollments")) {
            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0); 
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("enrollment_id"),
                        rs.getInt("studentID"),
                        rs.getInt("courseID"),
                        rs.getDate("enrollment_date"),
                        
                        
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
	
	
	private void fillEntryDetails(int entrollmentid) {
	    String query = "SELECT studentID,courseID FROM Enrollments WHERE enrollment_id = ?";
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, entrollmentid);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                
	                cmbStid.setSelectedItem(rs.getInt("studentID"));
	                cmbcourseid.setSelectedItem(rs.getInt("courseID"));
	               
	            } else {
	                JOptionPane.showMessageDialog(this, "No student found with ID: " + entrollmentid, "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(this, "Error fetching student details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	private void showStudentsForCourse(int courseId) {
	    String query = "SELECT s.studentId, s.firstName, e.enrollment_date " +
	                   "FROM Enrollments e " +
	                   "JOIN Students s ON e.studentID = s.studentId " +
	                   "WHERE e.courseID = ?";
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, courseId);
	        try (ResultSet rs = stmt.executeQuery()) {
	            
	            tableModel2.setRowCount(0); 
	            while (rs.next()) {
	                int studentId = rs.getInt("studentID");
	                String studentName = rs.getString("firstName");
	                Date enrollmentDate = rs.getDate("enrollment_date");
	                
	                tableModel2.addRow(new Object[]{studentId, studentName, enrollmentDate});
	            }
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(this, "Error fetching students for the course: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	private void showCourseReport(int courseId) {
	    try {
	        
	        String sourceFile = "src/studentsForCourseReport.jrxml";
	        String compiledFile = "src/course_report.jasper";
	        JasperCompileManager.compileReportToFile(sourceFile, compiledFile);

	        
	        List<StudentModel> students = EntrollmentModel.getStudentsByCourseId(courseId);  // Fetch the students enrolled in the course
	        if (students.isEmpty()) {
	            JOptionPane.showMessageDialog(null, "No students found for course ID: " + courseId);
	            return;
	        }

	        
	        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(students);

	        
	        JasperPrint jasperPrint = JasperFillManager.fillReport(compiledFile, null, dataSource);

	        
	        JasperViewer.viewReport(jasperPrint, false);

	    } catch (Exception e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
}
