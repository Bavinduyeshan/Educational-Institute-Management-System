package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.k33ptoo.components.KGradientPanel;

import Controller.LoginController;
import Model.LoginModel;

import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.MatteBorder;

import com.formdev.flatlaf.FlatLightLaf;
import com.k33ptoo.components.KButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RegisterForm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtusername;
	private JTextField txtpassword;
	private RegisterForm registerForm;
	private KButton btnSignup;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
						
					RegisterForm frame = new RegisterForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterForm() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 981, 624);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		KGradientPanel gradientPanel = new KGradientPanel();
		gradientPanel.setLayout(null);
		gradientPanel.kEndColor = new Color(0, 153, 204);
		gradientPanel.setkEndColor(new Color(0, 153, 204));
		gradientPanel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		gradientPanel.setBounds(0, 0, 981, 598);
		contentPane.add(gradientPanel);
		
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("E:\\icons\\fbbntn.png"));
		lblNewLabel.setBounds(91, 246, 307, 308);
		gradientPanel.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel.setBackground(Color.WHITE);
		panel.setBounds(535, 0, 436, 588);
		gradientPanel.add(panel);
		
		JLabel lblusername = new JLabel("Username");
		lblusername.setForeground(new Color(90, 90, 90));
		lblusername.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblusername.setBounds(22, 120, 149, 38);
		panel.add(lblusername);
		
		JLabel lblNewLabel_1_1 = new JLabel("Sign Up");
		lblNewLabel_1_1.setForeground(new Color(90, 90, 90));
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.BOLD, 24));
		lblNewLabel_1_1.setBounds(28, 38, 98, 38);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblpassword = new JLabel("Password");
		lblpassword.setForeground(new Color(90, 90, 90));
		lblpassword.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblpassword.setBounds(22, 245, 149, 38);
		panel.add(lblpassword);
		
		txtusername = new JTextField();
		txtusername.setColumns(10);
		txtusername.setBorder(new MatteBorder(0, 0, 2, 0, (Color) new Color(0, 0, 128)));
		txtusername.setBounds(62, 185, 283, 31);
		panel.add(txtusername);
		
		txtpassword = new JTextField();
		txtpassword.setColumns(10);
		txtpassword.setBorder(new MatteBorder(0, 0, 3, 0, (Color) new Color(0, 0, 128)));
		txtpassword.setBounds(62, 300, 283, 31);
		panel.add(txtpassword);
		
		JLabel lblNewLabel_2 = new JLabel("click here to go back to Login");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				JFrame registerForm = (JFrame) SwingUtilities.getWindowAncestor(lblNewLabel_2);
				if (registerForm != null) {
					registerForm.dispose(); 
					} 
				LoginModel loginModel=new LoginModel();
				LoginForm loginForm=new LoginForm();
				loginForm.setVisible(true);
				new LoginController(loginModel, loginForm);
			}
		});
		lblNewLabel_2.setForeground(new Color(183, 0, 183));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_2.setBounds(62, 438, 264, 27);
		panel.add(lblNewLabel_2);
		
		 btnSignup = new KButton();
		 btnSignup.kHoverForeGround = new Color(0, 0, 160);
		 btnSignup.setkHoverForeGround(new Color(0, 0, 160));
		btnSignup.setText("Sign Up");
		btnSignup.kStartColor = new Color(255, 85, 255);
		btnSignup.setkStartColor(new Color(255, 85, 255));
		btnSignup.kIndicatorColor = new Color(0, 0, 111);
		btnSignup.setkIndicatorColor(new Color(0, 0, 111));
		btnSignup.kForeGround = new Color(0, 0, 111);
		btnSignup.setkForeGround(new Color(0, 0, 111));
		btnSignup.kEndColor = new Color(0, 0, 225);
		btnSignup.setkEndColor(new Color(0, 0, 225));
		btnSignup.kBorderRadius = 40;
		btnSignup.setkBorderRadius(40);
		btnSignup.kBackGroundColor = Color.RED;
		btnSignup.setkBackGroundColor(Color.RED);
		btnSignup.setFont(new Font("Tahoma", Font.BOLD, 17));
		btnSignup.setBorder(null);
		btnSignup.setBounds(108, 381, 185, 45);
		panel.add(btnSignup);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Education Institute Management ");
		lblNewLabel_1_2_1.setForeground(new Color(0, 0, 160));
		lblNewLabel_1_2_1.setFont(new Font("Segoe UI", Font.BOLD, 28));
		lblNewLabel_1_2_1.setBounds(21, 113, 496, 45);
		gradientPanel.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("System");
		lblNewLabel_1_2_1_1.setForeground(new Color(0, 0, 160));
		lblNewLabel_1_2_1_1.setFont(new Font("Segoe UI", Font.BOLD, 28));
		lblNewLabel_1_2_1_1.setBounds(157, 179, 123, 45);
		gradientPanel.add(lblNewLabel_1_2_1_1);
		
		JLabel lblNewLabel_1_2_1_1_1 = new JLabel("Welcome");
		lblNewLabel_1_2_1_1_1.setForeground(new Color(0, 0, 160));
		lblNewLabel_1_2_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 28));
		lblNewLabel_1_2_1_1_1.setBounds(141, 61, 123, 45);
		gradientPanel.add(lblNewLabel_1_2_1_1_1);
	}
	
	public String  getUsername() {
		return txtusername.getText();
		
	}
	public String getPassword() {
		
		return txtpassword.getText();
		
	}
	
	public void addAddButtonListener(ActionListener listener) {
        btnSignup.addActionListener(listener);
    }
}
