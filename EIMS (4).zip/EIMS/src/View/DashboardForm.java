package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.k33ptoo.components.KGradientPanel;

import Config.DatabaseConnection;

import com.k33ptoo.components.KButton;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.border.LineBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class DashboardForm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblStudentCount;
	private JLabel lblCourseCount;
	private JLabel lblLectureCount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DashboardForm frame = new DashboardForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DashboardForm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("E:\\icons\\fbbntn.png"));
		setTitle("Education Institute Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1283, 894);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 250, 251));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		  
        MenuPanel menuPanel = new MenuPanel();
        menuPanel.setBackground(new Color(238, 250, 251));
        menuPanel.setBounds(10, 160, 210, 608);  // Adjust size if needed
        contentPane.add(menuPanel);
		
		KGradientPanel gradientPanel_1 = new KGradientPanel();
		gradientPanel_1.kStartColor = new Color(0, 128, 255);
		gradientPanel_1.setkStartColor(new Color(204, 107, 255));
		gradientPanel_1.kEndColor = new Color(138, 21, 255);
		gradientPanel_1.setkEndColor(new Color(51, 255, 255));
		gradientPanel_1.kBorderRadius = 25;
		gradientPanel_1.setBounds(350, 150, 271, 132);
		contentPane.add(gradientPanel_1);
		gradientPanel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Students");
		lblNewLabel.setBounds(77, 25, 119, 27);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 25));
		gradientPanel_1.add(lblNewLabel);
		
		 lblStudentCount = new JLabel("");
		lblStudentCount.setForeground(Color.WHITE);
		lblStudentCount.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblStudentCount.setBounds(23, 80, 238, 27);
		gradientPanel_1.add(lblStudentCount);
		
		KGradientPanel gradientPanel_2 = new KGradientPanel();
		gradientPanel_2.kBorderRadius = 25;
		gradientPanel_2.setkEndColor(new Color(255, 0, 0));
		gradientPanel_2.setkStartColor(new Color(255, 153, 153));
		gradientPanel_2.setBounds(685, 150, 258, 132);
		contentPane.add(gradientPanel_2);
		gradientPanel_2.setLayout(null);
		
		JLabel lblCourses = new JLabel("Courses");
		lblCourses.setBounds(73, 23, 103, 34);
		lblCourses.setForeground(Color.WHITE);
		lblCourses.setFont(new Font("Segoe UI", Font.BOLD, 25));
		gradientPanel_2.add(lblCourses);
		
		 lblCourseCount = new JLabel("");
		lblCourseCount.setForeground(Color.WHITE);
		lblCourseCount.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblCourseCount.setBounds(20, 82, 238, 27);
		gradientPanel_2.add(lblCourseCount);
		
		KGradientPanel gradientPanel_3 = new KGradientPanel();
		gradientPanel_3.setkStartColor(new Color(0, 255, 0));
		gradientPanel_3.kBorderRadius = 25;
		gradientPanel_3.setBounds(1028, 150, 258, 132);
		contentPane.add(gradientPanel_3);
		gradientPanel_3.setLayout(null);
		
		JLabel lblLectures = new JLabel("lectures");
		lblLectures.setBounds(82, 22, 103, 34);
		lblLectures.setForeground(Color.WHITE);
		lblLectures.setFont(new Font("Segoe UI", Font.BOLD, 25));
		gradientPanel_3.add(lblLectures);
		
		 lblLectureCount = new JLabel("");
		lblLectureCount.setForeground(Color.WHITE);
		lblLectureCount.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblLectureCount.setBounds(10, 79, 238, 27);
		gradientPanel_3.add(lblLectureCount);
		
		KGradientPanel gradientPanel_4 = new KGradientPanel();
		gradientPanel_4.setkStartColor(new Color(0, 0, 111));
		gradientPanel_4.kEndColor = new Color(0, 0, 111);
		gradientPanel_4.setkEndColor(new Color(0, 0, 111));
		gradientPanel_4.setkBorderRadius(40);
		gradientPanel_4.setBorder(null);
		gradientPanel_4.setBackground(new Color(238, 250, 251));
		gradientPanel_4.kBorderRadius = 40;
		gradientPanel_4.setBounds(240, 23, 1019, 60);
		contentPane.add(gradientPanel_4);
		gradientPanel_4.setLayout(null);
		
		JLabel lblDashboard = new JLabel("Dashboard");
		lblDashboard.setForeground(new Color(255, 255, 255));
		lblDashboard.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblDashboard.setBounds(501, 10, 166, 32);
		gradientPanel_4.add(lblDashboard);
		
		JLabel lblNewLabel_1 = new JLabel("Students");
		lblNewLabel_1.setIcon(new ImageIcon("E:\\icons\\gg.png"));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_1.setBounds(52, -1, 115, 151);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Students");
		lblNewLabel_2.setIcon(new ImageIcon("E:\\NIBMM DSE\\EAD\\student-management-systemss.png"));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_2.setBounds(411, 329, 897, 475);
		contentPane.add(lblNewLabel_2);
		
		
		loadStudentCount();
		loadCourseCount();
		loadLectureCount();
	}
	
	
	private void loadStudentCount() {
        
        
        String query = "SELECT COUNT(*) AS student_count FROM Students";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {
                int studentCount = resultSet.getInt("student_count");
                lblStudentCount.setText("Total Students: " + studentCount);
            }
        } catch (SQLException e) {
        	lblStudentCount.setText("Error loading student count!");
            e.printStackTrace();
        }
    }
	
	private void loadCourseCount() {
        
        
        String query = "SELECT COUNT(*) AS student_count FROM Courses";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {
                int studentCount = resultSet.getInt("student_count");
                lblCourseCount.setText("Total Courses: " + studentCount);
            }
        } catch (SQLException e) {
        	lblCourseCount.setText("Error loading Course count!");
            e.printStackTrace();
        }
    }
	
	
	private void loadLectureCount() {
        
        
        String query = "SELECT COUNT(*) AS Lecture_count FROM Lectures";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {
                int studentCount = resultSet.getInt("Lecture_count");
                lblLectureCount.setText("Total Lectures: " + studentCount);
            }
        } catch (SQLException e) {
        	lblLectureCount.setText("Error loading Lecture count!");
            e.printStackTrace();
        }
    }
}
