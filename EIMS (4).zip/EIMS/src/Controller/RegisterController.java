package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Model.RegisterModel;
import View.RegisterForm;

public class RegisterController {
	
	private RegisterModel registerModel;
	private RegisterForm registerForm;
	public RegisterController(RegisterModel registerModel, RegisterForm registerForm) {
		super();
		this.registerModel = registerModel;
		this.registerForm = registerForm;
		
		this.registerForm.addAddButtonListener(new AddLogin());
	}
	
	
	class AddLogin implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				registerModel.setUsername(registerForm.getUsername());
				registerModel.setPassword(registerForm.getPassword());
				
				registerModel.addLogin();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	}

}
