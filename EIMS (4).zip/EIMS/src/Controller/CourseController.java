package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Model.CourseModel;
import Model.LectureModel;
import View.CourseView;

public class CourseController {
	
	
	private CourseModel courseModel;
	private CourseView courseView;
	public CourseController(CourseModel courseModel, CourseView courseView) {
		super();
		this.courseModel = courseModel;
		this.courseView = courseView;
		courseView.fillLectureIdComboBox();
		courseView.fillCourseIdComboBox();
		this.courseView.addAddButtonListener(new ADDcourses());
		this.courseView.addUPDATEButtonListener(new updatecourses());
		this.courseView.addDELETEButtonListener(new deleteCourse());
	}
	
	class ADDcourses implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
	        courseModel.setCoursenmae(courseView.getCoursename());
	        courseModel.setCoursedes(courseView.getcoursedes());
	        courseModel.setCredits(courseView.getcredits());
	        courseModel.setLecid(courseView.getlecid());
	        
	        courseModel.addLecture();
	        courseView.fillCourseIdComboBox();
	        courseView.loadCourseData();
			
		}
		
	}
	
	
	class updatecourses implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			try {
				 courseModel.setCoursenmae(courseView.getCoursename());
			        courseModel.setCoursedes(courseView.getcoursedes());
			        courseModel.setCredits(courseView.getcredits());
			        courseModel.setLecid(courseView.getlecid());
			        courseModel.setCourseid(courseView.getCourseid());
			        
			        courseModel.updateCourse();
			        courseView.fillCourseIdComboBox();
			        courseView.loadCourseData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
	       
			
		}
		
	}
	
	
	
	class deleteCourse implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				courseModel.setCourseid(courseView.getCourseid());
				
				courseModel.deleteCourse();
				courseView.fillCourseIdComboBox();
				courseView.loadCourseData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
                System.out.println("Error occurred while deleting the Course.");

			}
			
		}
		
	}

}
