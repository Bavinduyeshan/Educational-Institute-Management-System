package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import Model.LoginModel;
import View.LoginForm;

public class LoginController {
	
		private LoginModel loginModel;
		private LoginForm loginForm;
		public LoginController(LoginModel loginModel, LoginForm loginForm) {
			super();
			this.loginModel = loginModel;
			this.loginForm = loginForm;
			
			this.loginForm.addAddButtonListener(new AddButtonListner());
		}
		
		
		class AddButtonListner implements ActionListener {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					loginModel.setUsername(loginForm.getUsername());
					loginModel.setPassword(loginForm.getPassword());
					
					loginModel.checkLogin();
					loginForm.dispose();
				} catch (Exception e2) {
					// TODO: handle exception
					e2.getMessage();
				}
				
			}
			
		}
}
