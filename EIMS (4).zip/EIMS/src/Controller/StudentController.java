package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;

import com.itextpdf.text.List;

import Model.StudentModel;
import View.StudentForm;


public class StudentController {
	
	private StudentForm studentForm;
	
	private StudentModel studentModel;
	
	

	public StudentController(StudentForm studentForm, StudentModel studentModel) {
		super();
		this.studentForm = studentForm;
		this.studentModel = studentModel;
		
		
		
		studentForm.fillStudentIdComboBox();
		studentForm.fillStudentIdSearchComboBox();
		
		
		this.studentForm.addAddButtonListener(new AddButtonListner());
		this.studentForm.addUPDATEButtonListener(new UPDATEButtonListner());
		this.studentForm.addDELETEButtonListener(new DELETEButtonListner());
		
	}
	
	class AddButtonListner implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				// Validate input
				String fname = studentForm.getFname();
				if (fname == null || fname.trim().isEmpty()) {
					JOptionPane.showMessageDialog(null, "First name cannot be empty", "Validation Error", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				
				
				studentModel.setFname(fname);
				studentModel.setLname(studentForm.getLname());
				studentModel.setGender(studentForm.getGender());
				studentModel.setAddress(studentForm.getAddress());
				studentModel.setEmail(studentForm.getEmail());
				
				
				studentModel.addStudent();
				studentForm.loadStudentData();
				studentForm.fillStudentIdComboBox();
				
				
				//JOptionPane.showMessageDialog(null, "Student added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
			} catch (Exception ex) {
				// Log and show error
				ex.printStackTrace();
				JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		
			
		}
		
	}
	
	
	class UPDATEButtonListner implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				studentModel.setFname(studentForm.getFname());
				studentModel.setLname(studentForm.getLname());
				studentModel.setGender(studentForm.getGender());
				studentModel.setAddress(studentForm.getAddress());
				studentModel.setEmail(studentForm.getEmail());
				studentModel.setStudentid(studentForm.getStudentID());
				
				studentModel.updateStudent();
				studentForm.loadStudentData();
			} catch (Exception e2) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(null, "Error: " + e2.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
			
		}
		
	}
	
	
	class DELETEButtonListner implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			 try {

	               studentModel.setStudentid(studentForm.getStudentID());


	               studentModel.deleteStudent();
	               studentForm.fillStudentIdComboBox();
	               studentForm.loadStudentData();
	            } catch (Exception ex) {
	                System.out.println("Error occurred while deleting the book.");
	            }
			
		}
		
	}
	
	
	


	
	

}
