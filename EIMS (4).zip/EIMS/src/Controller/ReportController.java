package Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import Model.EntrollmentModel;
import Model.StudentModel;

public class ReportController {

    public void generateStudentReport(int studentId) {
        try {
        	
        	
            JasperCompileManager.compileReportToFile("src/student_report.jrxml", "src/student_report.jasper");

            //student data getting
            List<StudentModel> students = StudentModel.getStudentById(studentId);
            if (students.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No student found with ID: " + studentId);
                return;
            }

            
            String reportPath = "src/student_report.jasper";
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(reportPath);

            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("studentId", studentId);

            
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(students);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);

            //show the reportggg
            JasperViewer.viewReport(jasperPrint, false);

        } catch (JRException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating report: " + e.getMessage());
        }
    }
    
    
    public void generateCourseReport(int courseId) {
        try {
            
            JasperCompileManager.compileReportToFile("src/studentsForCourseReport.jrxml", "src/course_report.jasper");

            
            List<StudentModel> students = EntrollmentModel.getStudentsByCourseId(courseId);
            if (students.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No students found for course ID: " + courseId);
                return;
            }

            
            String reportPath = "src/course_report.jasper";
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(reportPath);

            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("courseId", courseId); 

            
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(students);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);

           
            JasperViewer.viewReport(jasperPrint, false);

        } catch (JRException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating report: " + e.getMessage());
        }
    }
}
