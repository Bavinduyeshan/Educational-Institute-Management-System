package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Model.EntrollmentModel;
import View.DashboardForm;
import View.EntrollmetView;

public class EntrollmentController {
	
	
	private EntrollmentModel entrollmentModel;
	private EntrollmetView entrollmetView;
	public EntrollmentController(EntrollmentModel entrollmentModel, EntrollmetView entrollmetView) {
		super();
		this.entrollmentModel = entrollmentModel;
		this.entrollmetView = entrollmetView;
		entrollmetView.fillCourseIdComboBox();
		entrollmetView.fillStudentIdComboBox();
		entrollmetView.fillEntrollmentIdComboBox();
		entrollmetView.fillSearchCourseIdComboBox();
		
		this.entrollmetView.addAddButtonListener(new AddEntrollmentButton());
		
		this.entrollmetView.addUPDATEButtonListener(new updateEntrollment());
		this.entrollmetView.addDELETEButtonListener(new deleteEntrollment());
		//this.entrollmetView.addDashboardButtonListener(new DashboardButton());
	}
	
	
	
	class AddEntrollmentButton implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				entrollmentModel.setCourseid(entrollmetView.getCourseId());
				entrollmentModel.setStudentid(entrollmetView.getstudentId());
				
				entrollmentModel.addEntrollmet();
				entrollmetView.fillEntrollmentIdComboBox();
				entrollmetView.loadEntrollmentData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	}
	
	class updateEntrollment implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			try {

					entrollmentModel.setStudentid(entrollmetView.getstudentId());
					entrollmentModel.setCourseid(entrollmetView.getCourseId());
					entrollmentModel.setEntrollmentid(entrollmetView.getEntrolmentId());
			        
			        
			        entrollmentModel.updateEntrollment();;
			        entrollmetView.loadEntrollmentData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
	       
			
		}
		
	}
	
	
	
	class deleteEntrollment implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				entrollmentModel.setEntrollmentid(entrollmetView.getEntrolmentId());
				
				entrollmentModel.deleteEntrollment();
				entrollmetView.fillEntrollmentIdComboBox();
				entrollmetView.loadEntrollmentData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
                System.out.println("Error occurred while deleting the book.");

			}
			
		}
		
	}
	class DashboardButton implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			entrollmetView.dispose();
//			DashboardForm dashboardForm=new DashboardForm();
//			dashboardForm.setVisible(true);
			
		}
		
	}
	
	

}
