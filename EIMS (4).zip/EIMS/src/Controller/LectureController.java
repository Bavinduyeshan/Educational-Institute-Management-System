package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Model.LectureModel;
import View.lectureView;

public class LectureController {
	
	private LectureModel lectureModel;
	private lectureView lectureView;
	public LectureController(LectureModel lectureModel, View.lectureView lectureView) {
		super();
		this.lectureModel = lectureModel;
		this.lectureView = lectureView;
		lectureView.fillLectureIdComboBox();
		this.lectureView.addAddButtonListener(new AddLectureButton());
		this.lectureView.addUPDATEButtonListener(new UPdateButton());
		this.lectureView.addDELETEButtonListener(new DELETEButtonListner());
	}
	
	class AddLectureButton implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				lectureModel.setLecname(lectureView.getname());
				lectureModel.setGender(lectureView.getGender());
				lectureModel.setAddress(lectureView.getAddress());
				lectureModel.setEmail(lectureView.getEmail());
				
				lectureModel.addLecture();
				lectureView.fillLectureIdComboBox();
				lectureView.loadLectureData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	}
	
	
	
	class UPdateButton implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				lectureModel.setLecname(lectureView.getname());
				lectureModel.setGender(lectureView.getGender());
				lectureModel.setAddress(lectureView.getAddress());
				lectureModel.setEmail(lectureView.getEmail());
				lectureModel.setLectureId(lectureView.getLecid());
				
				lectureModel.updateLecture();
				lectureView.loadLectureData();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	}
	
	
	
	class DELETEButtonListner implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			 try {

	               lectureModel.setLectureId(lectureView.getLecid());


	               lectureModel.deleteLecturer();
	              lectureView.fillLectureIdComboBox();
	              lectureView.loadLectureData();
	            } catch (Exception ex) {
	                System.out.println("Error occurred while deleting the Lecture.");
	            }
			
		}
		
	}

}
