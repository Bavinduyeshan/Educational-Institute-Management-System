import com.formdev.flatlaf.FlatLightLaf;

import Controller.CourseController;
import Controller.EntrollmentController;
import Controller.LectureController;
import Controller.LoginController;
import Controller.StudentController;
import Model.CourseModel;
import Model.EntrollmentModel;
import Model.LectureModel;
import Model.LoginModel;
import Model.StudentModel;
import View.CourseView;
import View.EntrollmetView;
import View.LoginForm;
import View.StudentForm;
import View.lectureView;

public class Main {

	public static void main(String[] args) {
		
		
//		 //TODO Auto-generated method stub
		LoginModel loginModel=new LoginModel();
		LoginForm loginForm=new LoginForm();
		loginForm.setVisible(true);
//		
		new LoginController(loginModel, loginForm);
		
		
//		StudentModel studentModel=new StudentModel();
//		StudentForm studentForm=  new StudentForm();
//		studentForm.setVisible(true);
//		
//		new StudentController(studentForm, studentModel);
		
//		LectureModel lectureModel=new LectureModel();
//		lectureView lectureView= new lectureView();
//		lectureView.setVisible(true);
//		
//		new LectureController(lectureModel, lectureView);
		
		
//		CourseModel courseModel=new CourseModel();
//		CourseView courseView=new CourseView();
//		courseView.setVisible(true);
//		new CourseController(courseModel, courseView);
		
//		EntrollmentModel entrollmentModel=new EntrollmentModel();
//		EntrollmetView entrollmetView=new EntrollmetView();
//		entrollmetView.setVisible(true);
//		new EntrollmentController(entrollmentModel, entrollmetView);
	}

}
