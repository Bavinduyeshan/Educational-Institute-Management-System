package Model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import java.util.List;

import Config.DatabaseConnection;
import UserDesinedException.StudentException;

public class StudentModel {
	
	
	private int studentid;
	private String fname;
	private String lname;
	private Date dob;
	private String gender;
	private String address;
	private String email;
	private Date entrollmentDate;
	
	
	public Date getEntrollmentDate() {
		return entrollmentDate;
	}
	public void setEntrollmentDate(Date entrollmentDate) {
		this.entrollmentDate = entrollmentDate;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(Integer  studentid) {
		this.studentid = studentid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public void addStudent() throws StudentException{
		
		if (fname == null || fname.isEmpty()) {
	        throw new StudentException("First name cannot be empty.");
	    }
	    if (lname == null || lname.isEmpty()) {
	        throw new StudentException("Last name cannot be empty.");
	    }
	    String sqlString = "INSERT INTO Students (firstName, lastName, dob, gender, address, email) VALUES (?, ?, ?, ?, ?, ?)";

	    try (Connection connection = DatabaseConnection.getConnection();
	         PreparedStatement statement = connection.prepareStatement(sqlString)) {

	    	
	        
	        statement.setString(1, fname);
	        statement.setString(2, lname);
	        statement.setDate(3, dob);
	        statement.setString(4, gender);
	        statement.setString(5, address);
	        statement.setString(6, email);

	        
	        int rowsInserted = statement.executeUpdate();

	        
	        if (rowsInserted > 0) {
	            JOptionPane.showMessageDialog(null, "Student added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
	        } else {
	            JOptionPane.showMessageDialog(null, "Error adding student.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    } catch (Exception e) {
	        e.printStackTrace(); 
	        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	
	
	
	public void updateStudent() {
		
		String sqlString="UPDATE Students SET firstName=?, lastName=?, gender=?, address=?, email=? WHERE studentId=? ";
		
		try (Connection connection=DatabaseConnection.getConnection();
				PreparedStatement statement=connection.prepareStatement(sqlString)){
			
			 statement.setString(1, fname);
		        statement.setString(2, lname);
		        
		        statement.setString(3, gender);
		        statement.setString(4, address);
		        statement.setString(5, email);
		        statement.setInt(6, studentid);
		        
		        
		        int rowsInserted = statement.executeUpdate();

		        
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Student updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(null, "Error updating student.", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

		}
		
	}
	
	
	public void deleteStudent() {
		 String sql = "DELETE FROM Students WHERE studentID = ?";

	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(sql)) {

	            statement.setInt(1, studentid);

	            int rowsDeleted = statement.executeUpdate();
	            if(rowsDeleted>0) {
		            JOptionPane.showMessageDialog(null, "Student deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

	            }
	            else {
		            JOptionPane.showMessageDialog(null, "unable to delete student!", "error", JOptionPane.INFORMATION_MESSAGE);

	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "unable to delete student!it refers a foreign key constraint", "error", JOptionPane.INFORMATION_MESSAGE);

	            
	        }
	}
	
	
	
	
	public static List<StudentModel> getStudentById(int studentId) {
        List<StudentModel> students = new ArrayList<>(); 
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT studentId, firstName, lastName, dob, gender, address, email, enrollmentDate FROM Students WHERE studentId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                StudentModel student = new StudentModel();
                student.setStudentid(rs.getInt("studentId"));
                student.setFname(rs.getString("firstName"));
                student.setFname(rs.getString("lastName"));
                student.setDob(rs.getDate("dob"));
                student.setGender(rs.getString("gender"));
                student.setAddress(rs.getString("address"));
                student.setEmail(rs.getString("email"));
                student.setEnrollmentDate(rs.getString("enrollmentDate"));
                students.add(student);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return students;
    }
	private void setEnrollmentDate(String string) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	

	

}
