package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import Config.DatabaseConnection;

public class CourseModel {
		private int courseid;
		private String coursenmae;
		private String coursedes;
		private  int lecid;
		private int credits;
		public int getCourseid() {
			return courseid;
		}
		public void setCourseid(int courseid) {
			this.courseid = courseid;
		}
		public String getCoursenmae() {
			return coursenmae;
		}
		public void setCoursenmae(String coursenmae) {
			this.coursenmae = coursenmae;
		}
		public String getCoursedes() {
			return coursedes;
		}
		public void setCoursedes(String coursedes) {
			this.coursedes = coursedes;
		}
		public int getLecid() {
			return lecid;
		}
		public void setLecid(int lecid) {
			this.lecid = lecid;
		}
		public int getCredits() {
			return credits;
		}
		public void setCredits(int credits) {
			this.credits = credits;
		}
		
		
		public void addLecture() {
			
			String sqlString="INSERT INTO Courses(courseName,courseDescription,credits,lectureID) VALUES(?,?,?,?)";
			
			 try (Connection connection = DatabaseConnection.getConnection();
			         PreparedStatement statement = connection.prepareStatement(sqlString)) {

			    	
			        
			        statement.setString(1, coursenmae);
			        statement.setString(2, coursedes);
			        statement.setInt(3, credits);
			        statement.setInt(4, lecid);
			        

			       
			        int rowsInserted = statement.executeUpdate();

			        
			        if (rowsInserted > 0) {
			            JOptionPane.showMessageDialog(null, "Course added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
			        } else {
			            JOptionPane.showMessageDialog(null, "Error adding Course.", "Error", JOptionPane.ERROR_MESSAGE);
			        }
			    } catch (Exception e) {
			        e.printStackTrace(); 
			        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			    }
			
		}
		
		public void updateCourse() {
			
			String sqlString="UPDATE Courses SET courseName=?,courseDescription=?,credits=?,lectureID=? WHERE courseID=? ";
			
			try (Connection connection=DatabaseConnection.getConnection();
					PreparedStatement statement=connection.prepareStatement(sqlString)){
				
				 statement.setString(1, coursenmae);
			        statement.setString(2, coursedes);
			        statement.setInt(3, credits);
			        statement.setInt(4, lecid);
			        statement.setInt(5, courseid);
			        
			        
			        int rowsInserted = statement.executeUpdate();

			        
			        if (rowsInserted > 0) {
			            JOptionPane.showMessageDialog(null, "course updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
			        } else {
			            JOptionPane.showMessageDialog(null, "Error updating course", "Error", JOptionPane.ERROR_MESSAGE);
			        }
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

			}
			
		}
//		
		public void deleteCourse() {
			 String sql = "DELETE FROM Courses WHERE courseID = ?";

		        try (Connection connection = DatabaseConnection.getConnection();
		             PreparedStatement statement = connection.prepareStatement(sql)) {

		            statement.setInt(1, courseid);

		            int rowsDeleted = statement.executeUpdate();
		            if(rowsDeleted>0) {
			            JOptionPane.showMessageDialog(null, "Course deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

		            }
		            else {
			            JOptionPane.showMessageDialog(null, "unable to delete Course!", "error", JOptionPane.INFORMATION_MESSAGE);

		            }

		        } catch (SQLException e) {
		            e.printStackTrace();
		            JOptionPane.showMessageDialog(null, "unable to delete Course! it reffers a forign key constraint", "error", JOptionPane.INFORMATION_MESSAGE);

		            
		        }
		        catch (Exception ex) {
					// TODO: handle exception
		        	ex.printStackTrace();
				}
		}
		
		
		
}
