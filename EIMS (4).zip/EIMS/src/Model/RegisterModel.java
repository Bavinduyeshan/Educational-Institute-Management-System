package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import Config.DatabaseConnection;

public class RegisterModel {
	private String username;
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public void addLogin() {
		
		String sqlString="INSERT INTO Login(username,password) VALUES(?,?)";
		
		 try (Connection connection = DatabaseConnection.getConnection();
		         PreparedStatement statement = connection.prepareStatement(sqlString)) {

		    	
		        
		        statement.setString(1, username);
		        statement.setString(2, password);
		        
		        

		        
		        int rowsInserted = statement.executeUpdate();

		        
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Login added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(null, "Error adding Login.", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    } catch (Exception e) {
		        e.printStackTrace(); 
		        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		    }
		
	}
}
