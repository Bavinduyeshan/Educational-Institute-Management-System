package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import Config.DatabaseConnection;

public class LectureModel {
	private int lectureId;
	private String lecname;
	private String address;
	private String gender;
	private String email;
	
	
	public int getLectureId() {
		return lectureId;
	}
	public void setLectureId(int lectureId) {
		this.lectureId = lectureId;
	}
	public String getLecname() {
		return lecname;
	}
	public void setLecname(String lecname) {
		this.lecname = lecname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void addLecture() {
		
		String sqlString="INSERT INTO Lectures(lectureName,gender,Address,email) VALUES(?,?,?,?)";
		
		 try (Connection connection = DatabaseConnection.getConnection();
		         PreparedStatement statement = connection.prepareStatement(sqlString)) {

		    	
		        
		        statement.setString(1, lecname);
		        statement.setString(2, gender);
		        statement.setString(3, address);
		        statement.setString(4, email);
		        

		        
		        int rowsInserted = statement.executeUpdate();

		        
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Lecture added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(null, "Error adding Lecture.", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    } catch (Exception e) {
		        e.printStackTrace(); 
		        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		    }
		
	}
	
	public void updateLecture() {
		
		String sqlString="UPDATE Lectures SET lectureName=?,gender=?,Address=?,email=? WHERE lectureID=? ";
		
		try (Connection connection=DatabaseConnection.getConnection();
				PreparedStatement statement=connection.prepareStatement(sqlString)){
			
			statement.setString(1, lecname);
	        statement.setString(2, gender);
	        statement.setString(3, address);
	        statement.setString(4, email);
	        statement.setInt(5, lectureId);
		        
		        
		        int rowsInserted = statement.executeUpdate();

		        
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Lecture updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(null, "Error updating Lectures.", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

		}
		
	}
	
	public void deleteLecturer() {
		 String sql = "DELETE FROM Lectures WHERE lectureID = ?";

	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(sql)) {

	            statement.setInt(1, lectureId);

	            int rowsDeleted = statement.executeUpdate();
	            if(rowsDeleted>0) {
		            JOptionPane.showMessageDialog(null, "Lecture deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

	            }
	            else {
		            JOptionPane.showMessageDialog(null, "unable to delete Lecture!", "error", JOptionPane.INFORMATION_MESSAGE);

	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "unable to delete Lecture! it refers a foreign key constaraint", "error", JOptionPane.INFORMATION_MESSAGE);

	            
	        }
	}
	
	
	
	
 
	

}
