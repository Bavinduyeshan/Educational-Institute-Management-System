package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Config.DatabaseConnection;

public class EntrollmentModel {
	
	
	private int entrollmentid;
	private int studentid;
	private int courseid;
	public int getEntrollmentid() {
		return entrollmentid;
	}
	public void setEntrollmentid(int entrollmentid) {
		this.entrollmentid = entrollmentid;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public int getCourseid() {
		return courseid;
	}
	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}
	
	
	public void addEntrollmet() {
		
		String sqlString="INSERT INTO Enrollments(studentID,courseID) VALUES(?,?)";
		
		 try (Connection connection = DatabaseConnection.getConnection();
		         PreparedStatement statement = connection.prepareStatement(sqlString)) {

		    	
		        
		        statement.setInt(1, studentid);
		        statement.setInt(2, courseid);
		        
		        

		        
		        int rowsInserted = statement.executeUpdate();

		        
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Entrollment  added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(null, "Error adding Entrollment.", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    } catch (Exception e) {
		        e.printStackTrace(); 
		        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		    }
		
	}
	
	
	public static List<StudentModel> getStudentsByCourseId(int courseId) {
	    List<StudentModel> students = new ArrayList<>(); // 
	    String query = "SELECT s.studentId, s.firstName, s.lastName, e.enrollment_date " +
	                   "FROM Enrollments e " +
	                   "JOIN Students s ON e.studentID = s.studentId " +
	                   "WHERE e.courseID = ?";
	    
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(query)) {
	        
	        ps.setInt(1, courseId);  
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                StudentModel student = new StudentModel();
	                student.setStudentid(rs.getInt("studentId"));
	                student.setFname(rs.getString("firstName"));
	                student.setLname(rs.getString("lastName"));
	                student.setEntrollmentDate(rs.getDate("enrollment_date"));
	                
	                students.add(student);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
	    return students;
	}
	
	
	
	public void updateEntrollment() {
		
		String sqlString="UPDATE Enrollments SET studentID=?,courseID=? WHERE enrollment_id=? ";
		
		try (Connection connection=DatabaseConnection.getConnection();
				PreparedStatement statement=connection.prepareStatement(sqlString)){
			
			 
		        statement.setInt(1, studentid);
		        statement.setInt(2, courseid);
		        statement.setInt(3, entrollmentid);
		        
		        
		        
		        int rowsInserted = statement.executeUpdate();

		        // Provide feedback to the user
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Entrollmetn  updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(null, "Error updating Entrollment", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

		}
		
	}
//	
	public void deleteEntrollment() {
		 String sql = "DELETE FROM Enrollments WHERE enrollment_id = ?";

	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(sql)) {

	            statement.setInt(1, entrollmentid);

	            int rowsDeleted = statement.executeUpdate();
	            if(rowsDeleted>0) {
		            JOptionPane.showMessageDialog(null, "Entrollment deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

	            }
	            else {
		            JOptionPane.showMessageDialog(null, "unable to delete Entrollment!", "error", JOptionPane.INFORMATION_MESSAGE);

	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            
	        }
	        catch (Exception ex) {
				// TODO: handle exception
	        	ex.printStackTrace();
			}
	}


}
