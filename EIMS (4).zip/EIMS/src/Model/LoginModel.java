package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import Config.DatabaseConnection;
import View.DashboardForm;
import View.RegisterForm;
import View.StudentForm;

public class LoginModel {
	
	private String username;
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public void checkLogin() {
		
		 String sql = "SELECT * FROM Login WHERE username=? AND password=?";

	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(sql)) {

	            statement.setString(1, username);
	            statement.setString(2, password);
	            

	            try (ResultSet resultSet=statement.executeQuery()){
	            	if (resultSet.next()) {
	            		System.out.println("login succesfull");
	            		//JOptionPane.showMessageDialog( null,"Login succesful","Login ",JOptionPane.OK_OPTION);
			            JOptionPane.showMessageDialog(null, "Login succesful!", "Login", JOptionPane.INFORMATION_MESSAGE);

//						RegisterForm registerForm=new RegisterForm();
//						registerForm.setVisible(true);
	            		;
	            		
	            		DashboardForm dashboardForm=new DashboardForm();
	            		dashboardForm.setVisible(true);
						
					}
	            	else {
						System.out.println("invalid credentials");
						JOptionPane.showMessageDialog( null,"invalid credentials","Login ",JOptionPane.OK_OPTION);
						
					}
	            	
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	            
	        }
	        catch (Exception ex){
	            ex.printStackTrace();
	            
	        }
		
	}
	
	
	

}
